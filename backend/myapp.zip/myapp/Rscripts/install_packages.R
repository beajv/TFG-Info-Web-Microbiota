#!/usr/bin/env Rscript
install.packages(c("RcppEigen", "lme4", "pbkrtest","emmeans","car","optparse","readxl", "stringr","dplyr","rstatix","FactoMineR","ggpubr","factoextra"), repo = "https://cloud.r-project.org")
